AIM-PU CLEAR-WIN (Full Bench)
Timestamp: 20251026_014733

Scenario:
- Reward features use softplus(Wx+b) aligned with our policy; post-shift winners change.
- Regime shift at t=300 with heavy-tailed volatility spikes.
- Diagonal-dominant reinforcement (allocation quality matters).
- Methods: ours, ctx-misaligned, static, random.
- Metrics: cumulative regret, post-shift regret, overall & post-shift allocation efficiency.

Artifacts live under 'plots/' and 'tables/'. See manifest.json for details.
